# ELITE FOOTBALL ANALYSIS — Android project

This is the complete first-version source project for an offline-first football analysis app. It is **not yet a compiled APK**. Compile it with Android Studio / Android SDK to produce the installable APK.

## Included
- Match creation and local match history
- Local video playback, speed controls and timestamped event tagging
- Tactical pitch with selectable formations and draggable player markers
- Drawing tools: arrows, lines, circles and rectangles
- Player scouting records
- Team tactical notes: build-up, pressing, transitions, defensive organisation and chance creation
- Manual match statistics, including possession, shots, pass completion and xG
- Set-piece planning notes
- Printable match report (Android print-to-PDF)
- English / Kiswahili interface
- JSON backup and restore
- Data stored locally in the browser/app WebView

## Important limitations
- The app does not connect to live match-data providers.
- It does not automatically recognise events from video or perform AI video analysis.
- Statistics and analyst notes are only as reliable as the information entered by the analyst.
- Video file access and playback depend on the Android WebView and selected local file permissions.

## Build a debug APK
Requirements: Node.js 20+, Java JDK 17, Android Studio with Android SDK installed.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
The debug APK is normally created at:

`android/app/build/outputs/apk/debug/app-debug.apk`

## Build using GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Open Actions and run **Build Android APK**.
3. Download the `elite-football-analysis-debug-apk` artifact after the workflow succeeds.

The workflow builds a debug APK and uploads it as an artifact. It does not sign a Play Store release APK.

## App identity
- Name: ELITE FOOTBALL ANALYSIS
- Application ID: `tz.mkude.elitefootballanalysis`
- Theme: dark navy, white and gold
